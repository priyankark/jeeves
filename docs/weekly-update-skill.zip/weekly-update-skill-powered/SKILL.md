---
name: weekly-update-skill-powered
description: "Run the Weekly update · Skill-powered workflow. A scheduled Codex specialist uses the installed internal-comms skill to draft a status update from synthetic facts."
compatibility: "Requires Node.js 22.12+, shell execution permission, network access for remote providers, and the credentials/tools listed in references/requirements.md."
---

# Weekly update · Skill-powered

Use this skill to execute the bundled workflow when the user's task matches its purpose. The workflow and nested agents run through the included engine; do not manually imitate their outputs.

1. Read [requirements](references/requirements.md) and check the environment with `node <skill-directory>/scripts/run.cjs --check`. Resolve missing tools or credentials through the user's environment; do not write secrets into this skill.
2. Create an input JSON file using [the example](input.example.json) and the user's actual task. Preserve the configured input structure.
3. For a simulation use `node <skill-directory>/scripts/run.cjs --mode demo --input <input-file> --output <writable-directory>`. For the user's requested real execution use `--mode live`. The live mode calls the listed providers and may perform the listed HTTP actions; stay within the user's requested scope.
4. Read the JSON report on stdout and the saved run/result files. Report actual results and failures. Do not automatically rerun failed external actions.

A harness must be able to launch Node and write output files. The skill does not require the Jeeves desktop app, npm install, or a Jeeves account. Use `--help` for provider/model overrides and checkpoint recovery.
