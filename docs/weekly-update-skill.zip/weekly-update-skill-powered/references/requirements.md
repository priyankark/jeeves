# Weekly update · Skill-powered: execution requirements

A scheduled Codex specialist uses the installed internal-comms skill to draft a status update from synthetic facts.

- Runtime: Node.js 22.12+; Codex CLI with authentication
- Environment: ENABLE_CODEX=true
- Models: None
- Allowed HTTP origins: None
- External writes: None
- Bundled agent skills: internal-comms (anthropics/skills@33375500bcea98d610eb30ce10ac4e59b89c390d)

Environment values are read from the process or a .env file in the invoking working directory. API keys are never bundled. Codex steps require the Codex executable and an authenticated account or API setup. Local model steps require an accessible compatible server and model. Use --provider and --model to explicitly replace agent providers if needed.

Workflow license: MIT. Runner: MIT. Bundled skills retain their own licenses and notices embedded in workflow.json. API harnesses use skill instructions and text references; they do not gain script execution tools. The Codex harness stays read-only.
